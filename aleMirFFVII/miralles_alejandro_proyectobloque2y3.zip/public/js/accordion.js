$(document).ready(function(){
	$("#content").accordion({
		active : 0,
		heightStyle: "Content",
	});
});