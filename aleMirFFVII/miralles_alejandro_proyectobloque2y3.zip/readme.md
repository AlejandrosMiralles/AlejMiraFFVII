Archivos del proyecto final de Alejandro Miralles Ruiz, estudiante de 2n DAW presencial del IES El Caminas. 
Si desea conocer la estructura interna de la página lea el fichero readme.md en la carpeta public. 
Si en cambio desea ver la página en marcha, utilice en una máquina con Composer el siguiente comando en esta carpeta: "composer install". De esta manera podrá ver está página cuando desee con solo escribir, en esta carpeta, el comando "php -S 127.0.0.1 -t ./public/" y acceder a la ruta 127.0.0.1 puerto 80 (127.0.0.1:8000) desea cualquier navegador.
En un futuro se subirá la página en un servidor para que pueda acceder cualquier persona. 
