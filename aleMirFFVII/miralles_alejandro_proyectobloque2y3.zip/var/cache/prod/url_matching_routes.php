<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/admin/manageFeedback' => [[['_route' => 'app_manage_feedback', '_controller' => 'App\\Controller\\AdminController::manageFeedback'], null, null, null, false, false, null]],
        '/admin/deleteFeedback' => [[['_route' => 'app_delete_feedback', '_controller' => 'App\\Controller\\AdminController::deleteFeedback'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'app_index', '_controller' => 'App\\Controller\\GeneralController::index'], null, null, null, false, false, null]],
        '/informacionJuego' => [[['_route' => 'app_generalInfo', '_controller' => 'App\\Controller\\GeneralController::generalInfo'], null, null, null, false, false, null]],
        '/sendFeedback' => [[['_route' => 'app_sendFeedback', '_controller' => 'App\\Controller\\GeneralController::sendFeeback'], null, null, null, false, false, null]],
        '/monstruos' => [[['_route' => 'app_monsters', '_controller' => 'App\\Controller\\MonstersController::index'], null, null, null, false, false, null]],
        '/monstruos/joker' => [[['_route' => 'app_monsters_joker', '_controller' => 'App\\Controller\\MonstersController::joker'], null, null, null, false, false, null]],
        '/monstruos/soldadoRaso' => [[['_route' => 'app_monsters_soldadoRaso', '_controller' => 'App\\Controller\\MonstersController::soldadoRaso'], null, null, null, false, false, null]],
        '/monstruos/ladron' => [[['_route' => 'app_monsters_ladron', '_controller' => 'App\\Controller\\MonstersController::ladron'], null, null, null, false, false, null]],
        '/monstruos/serpienteKalm' => [[['_route' => 'app_monsters_serpienteKalm', '_controller' => 'App\\Controller\\MonstersController::serpienteKalm'], null, null, null, false, false, null]],
        '/admin/register' => [[['_route' => 'app_register', '_controller' => 'App\\Controller\\RegistrationController::register'], null, null, null, false, false, null]],
        '/admin/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/admin/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
    ],
    [ // $dynamicRoutes
    ],
    null, // $checkCondition
];
