<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_88e35171f80bf873969c60dc5813ac47 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'keywords' => [$this, 'block_keywords'],
            'description' => [$this, 'block_description'],
            'javascripts' => [$this, 'block_javascripts'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3c.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">

<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"es\"> 
  <head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" >
    <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title> 
    <link rel=\"shortcut icon\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/logoFavicon.ico"), "html", null, true);
        echo "\" type=\"image/x-icon\" >

    <meta charset=\"utf-8\" />
    <meta name=\"keywords\" content=";
        // line 10
        $this->displayBlock('keywords', $context, $blocks);
        echo " >
    <meta name=\"author\" content=\"Alejandro Miralles Ruiz, estudiante de 2n DAW presencial en el IES El Caminas\">
    <meta name=\"description\" content=";
        // line 12
        $this->displayBlock('description', $context, $blocks);
        echo " >
  

    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>



    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("styles/styleGeneral.css"), "html", null, true);
        echo "\" media=\"screen\" >

    ";
        // line 23
        $context["morningMode"] = (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 23), "cookies", [], "any", false, false, false, 23), "get", [0 => "morningMode"], "method", false, false, false, 23) == "true");
        // line 24
        echo "
    ";
        // line 25
        if (($context["morningMode"] ?? null)) {
            // line 26
            echo "      <link rel=\"stylesheet\" type=\"text/css\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("styles/styleDia.css"), "html", null, true);
            echo "\" media=\"screen\" >
    ";
        } else {
            // line 28
            echo "      <link rel=\"stylesheet\" type=\"text/css\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("styles/styleNoche.css"), "html", null, true);
            echo "\" media=\"screen\" >
    ";
        }
        // line 30
        echo "

    <script src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/Cookies.js"), "html", null, true);
        echo "\"></script>
    ";
        // line 33
        $this->displayBlock('javascripts', $context, $blocks);
        // line 34
        echo "
  </head>
  <body>

    <div id=\"top\" class=\"row show-grid\">
      
      <div class=\"container separate-rows tall rows\">
        
        <div class=\"col-md-12\">
          <header>
            <span class=\"h1\"><a id=\"home\" href=\"";
        // line 44
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_index");
        echo "\">Final Fantasy VII</a></span>
          </header>
        </div>
      </div>

      
      <div class=\"container separate-rows tall rows\">
        <div class=\"col-md-12\">
          <nav>
            ";
        // line 53
        if ( !($context["morningMode"] ?? null)) {
            // line 54
            echo "              <p name=\"Boton_cambio_dia\" class=\"Boton_modo_dia\"><a type=\"text/html\" hreflang=\"es\">Modo noche</a></p>
            ";
        } else {
            // line 56
            echo "              <p name=\"Boton_cambio_dia\" class=\"Boton_modo_noche\"><a type=\"text/html\" hreflang=\"es\">Modo dia</a></p>
            ";
        }
        // line 58
        echo "          
          </nav>
        </div>
      </div>
      

    </div>

    <div id=\"center\" class=\"row show-grid\">
      <div class=\"container separate-rows tall rows\">
        <div class=\"col-md-12\">
          <content>
            ";
        // line 70
        $this->displayBlock('content', $context, $blocks);
        // line 73
        echo "          </content>
        </div>
        
      </div>
      
    </div>
        

        
    <div id=\"footer\" class=\"row show-grid\">
      <div class=\"container separate-rows tall rows\">
        <div class=\"col-md-12\">
          <footer>
            ";
        // line 86
        $this->displayBlock('footer', $context, $blocks);
        echo " <br>
            <p>La <a href=\"https://www.flickr.com/photos/clf/44021925\">imagen de la cabecera</a> está sujeta a la siguiente licencia: <a href=\"https://creativecommons.org/licenses/by-nc-nd/2.0/\"> Creative Commons</a></p>
            <p><span property=\"dct:title\">FFVIIWiki</span> by <span property=\"cc:attributionName\">Alumir3453</span> is licensed under <a href=\"http://creativecommons.org/licenses/by-sa/4.0/?ref=chooser-v1\" target=\"_blank\" rel=\"license noopener noreferrer\" style=\"display:inline-block;\">CC BY-SA 4.0<img style=\"height:22px!important;margin-left:3px;vertical-align:text-bottom;\" src=\"https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1\" alt=\"creativeCommosImage\"><img alt=\"atributionImage\" style=\"height:22px!important;margin-left:3px;vertical-align:text-bottom;\" src=\"https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1\"><img alt=\"shareAlikeImage\" style=\"height:22px!important;margin-left:3px;vertical-align:text-bottom;\" src=\"https://mirrors.creativecommons.org/presskit/icons/sa.svg?ref=chooser-v1\"></a></p>
            <p>© 1997, 2019 SQUARE ENIX CO., LTD. All Rights Reserved. CHARACTER DESIGN: TETSUYA NOMURA LOGO ILLUSTRATION:© 1997 YOSHITAKA AMANO</p>
            
          </footer>
        </div>
        
      </div>
    </div>



  </body>
</html>";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 10
    public function block_keywords($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 12
    public function block_description($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 33
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 70
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 71
        echo "            
            ";
    }

    // line 86
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  228 => 86,  223 => 71,  219 => 70,  213 => 33,  207 => 12,  201 => 10,  195 => 6,  176 => 86,  161 => 73,  159 => 70,  145 => 58,  141 => 56,  137 => 54,  135 => 53,  123 => 44,  111 => 34,  109 => 33,  105 => 32,  101 => 30,  95 => 28,  89 => 26,  87 => 25,  84 => 24,  82 => 23,  77 => 21,  65 => 12,  60 => 10,  54 => 7,  50 => 6,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "base.html.twig", "/home/alumno/Escritorio/ProyectoFinal/AlejMiraFFVII/aleMirFFVII/templates/base.html.twig");
    }
}
