<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* monsters/soldadoRaso.html.twig */
class __TwigTemplate_9a17816a98e81f3e85cf9a67fafddbf1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'keywords' => [$this, 'block_keywords'],
            'description' => [$this, 'block_description'],
            'javascripts' => [$this, 'block_javascripts'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "monsters/soldadoRaso.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Soldado Raso";
    }

    // line 5
    public function block_keywords($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"wiki, FFVII, final fantasy, final fantasy 7, final fantasy VII, informacion, enemigo, monstruo, soldado raso, ejercito, Rufus, soldado, raso, Shinra, guerrero, combatiente, recluta, militante\"";
    }

    // line 7
    public function block_description($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"Pagina que reune toda la informacion del monstruo de FFVII el soldado raso.\"";
    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/ExpandImg.js"), "html", null, true);
        echo "\"></script> ";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "                <h2><a id=\"home2\" hreflang=\"es\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_index");
        echo "\">Home</a>-<a hreflang=\"es\" type=\"text/html\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters");
        echo "\">Monstruos</a>-Soldado Raso</h2>
                <br/><h1>Soldado Raso</h1><br/>
                <img class=\"adjunto\" alt=\"Imagen de un soldado\" src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/SoldadoRaso.png"), "html", null, true);
        echo "\" width=\"300\"/>
                <!--HTML para crear una nueva imagen. Es la misma de arriba pero más grande-->
                <div id=\"myModal\" class=\"modal\">
                    <span class=\"close\">&times;</span>
                    <img class=\"modal-content\" id=\"img01\">
                    <div id=\"caption\"></div>
                </div>
                
                <p><br/>Los soldados rasos son monstruos sin debilidades. Suelen aparecer en Midgar, aunque dependiendo del punto de la historia aparecen en otros lugares.
                    <br/><br/><br/>
                    Predominan en aquellos lugares en los que esté Shinra, como el edificio Shinra o allá donde Rufus.
                    <br/><br/>
                    Aunque en la imagen se muestre con un traje azul y un casco blanco, los soldados tienen distintos vestuarios dependiendo de su rango:
                    soldado, capitán de tropa, capitán, general, coronel, terratiniente, etc.
                </p>
                <table>
                    <caption>Tabla entre nivel hp magia y movimientos</caption>
                    <thead>
                        <tr>
                            <th scope=\"row\">Nivel</th>
                            <th></th>
                            <th scope=\"col\">5</th>
                            <th scope=\"col\">9</th>
                            <th scope=\"col\">20</th>
                            <th scope=\"col\">40</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope=\"row\">Experiencia</th>
                            <th></th>
                            <td>50</td>
                            <td>90</td>
                            <td>190</td>
                            <td>375</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Vida</th>
                            <th></th>
                            <td>200</td>
                            <td>400</td>
                            <td>1900</td>
                            <td>5000</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Magia</th>
                            <th></th>
                            <td>40</td>
                            <td>60</td>
                            <td>120</td>
                            <td>400</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Movimientos</th>
                            <th></th>
                            <td colspan=\"2\">Sable especial</td>
                            <td rowspan=\"2\">Nada</td>
                            <td>Piro 3</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Objetos</th>
                            <th></th>
                            <td colspan=\"2\">Poción</td>
                            <td>Sable Soldado Raso</td>
                        </tr>
                    </tbody>   
                </table>
";
    }

    // line 84
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "monsters/soldadoRaso.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 84,  93 => 14,  85 => 12,  81 => 11,  72 => 9,  65 => 7,  58 => 5,  51 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "monsters/soldadoRaso.html.twig", "/home/alumno/Escritorio/ProyectoFinal/AlejMiraFFVII/aleMirFFVII/templates/monsters/soldadoRaso.html.twig");
    }
}
