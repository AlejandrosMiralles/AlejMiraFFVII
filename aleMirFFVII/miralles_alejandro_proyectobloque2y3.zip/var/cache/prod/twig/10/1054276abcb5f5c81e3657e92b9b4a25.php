<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* general/generalInfo.html.twig */
class __TwigTemplate_1b3107d22350e150859855070cd8860f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'keywords' => [$this, 'block_keywords'],
            'description' => [$this, 'block_description'],
            'javascripts' => [$this, 'block_javascripts'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "general/generalInfo.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_keywords($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"wiki, FFVII, final fantasy, final fantasy 7, final fantasy VII, informacion, datos, ventas, gameplay, historia, compra, feedback, retroalimentacion, mecanicas, jugabilidad\"";
    }

    // line 5
    public function block_description($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"Pagina que que cuenta la historia y gameplay del juego FFVII y toda información relacionada a este.\" ";
    }

    // line 7
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "  <script src=\"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
  <script src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/accordion.js"), "html", null, true);
        echo "\"></script>
";
    }

    // line 13
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 14
        echo "        <h2>Juego</h2><br/>

        <p>Final Fantasy es uno de los juegos más populares de la saga Final Fantasy. <abbr title=\"Final Fantasy 7\">FFVII</abbr> ha llegado a vender más de 12,3 millones de copias desde su lanzamiento.
        <br>Su éxito se debe a muchas razones, como su historia, <dfn title=\"Se lanzó con el lanzamiento de la PlayStation1. Y fue el primer Final Fantasy en llegar a Europa.\"><em>el momento en que se lanzó</em></dfn>, 
        las <dfn title=\"Increíbles gráficos para la época, una historia muy larga, etc.\">capacidades del juego</dfn>, su gameplay,etc.</p>
        <div id=\"content\">

          <h3>Gameplay</h3>
          <div id=\"gameplay\"> 
            <p> El juego en un rpg basado en turnos. Cada personaje tiene una barra que se va llenando. Cuando lo hace, este puede escoger algún comandos entre los que tiene disponibles. <br/>
            Los comandos básicos son \"Ataque\" y \"Elementos\". Con el primero atacas al objetivo y con el segundo utilizas algún objeto. El resto de comandos se desbloquean utilizando materias.<br/>
            Las materias son objetos equipables a los personajes que les permiten o usar magia, invocar o usar comandos especiales. El número de materias equipables viene determinada por el arma equipada.<br/>
            De estas acciones, la más importante es la magia, sin lugar a dudas. El número de magias, su poder, su diversidad y su gestión las hacen las materias más <dfn title=\"No individualmente, si no en conjunto.\">importantes.</dfn> Además, son las responsables de darle chicha al gameplay.<br/>
            Aquí se presenta una lista de algunas de las magias con su correspondiente efecto:</p>
            <a id=\"magias\"></a>
            <dl>
              <dt><img alt=\"Materia fuego\" src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Fuego  </dt>
              <dd>Magia de fuego que lanza una llamarada al objetivo. Tiene hasta 3 niveles</dd>
              <dt><img alt=\"Materia hielo\" src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Hielo</dt>
              <dd>Magia de hielo que congela y daña al objetivo. Tiene hasta 3 niveles</dd>
              <dt><img alt=\"Materia electro\" src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Electro</dt>
              <dd>Magia de electricidad que electrocuta al objetivo. Tiene hasta 3 niveles.</dd>
              <dt><img alt=\"Materia Cura\" src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Cura</dt> 
              <dd>Cura al objetivo. Tiene hasta 3 niveles.</dd>
              <dt><img alt=\"Materia Gravedad\" src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Gravedad</dt>
              <dd>Daña al rival en proporción a su salud. El primer nivel quita un 25%, el segundo 50% y el tercero un 75%</dd>
              <dt><img alt=\"Materia Sentir\" src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaAmarilla.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Sentir</dt> 
              <dd>Libra. Chequea el nivel, el nombre, la salud y la magia del objetivo.</dd>
              <dt><img alt=\"Materia Cometa\" src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Cometa</dt>
              <dd>Poderosa magia que ataca a diversos objetivos a la vez. Tiene hasta 2 niveles.</dd>
              <dt><img alt=\"Materia Bios\" src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Bios</dt>
              <dd>Magia de envenenamiento que daña al rival. Tiene hasta 3 niveles.</dd>
              <dt><img alt=\"Materia Prisa\" src=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MateriaVerde.jpeg"), "html", null, true);
        echo "\" width=\"10\"/> Prisa</dt>
              <dd>Magia que acorta la espera de un personaje para actuar.</dd>
            </dl>
          </div>

          <h3>Historia</h3>
          <div id=\"historia\">
            <p>Entre todos los jrps, el FF7 destaca también por su historia. No contaré mucho para no destrozarle el juego a nadie, pero puedo decir que tiene una historia sorprendentemente larga. Puedes pensar que estás a punto de pasarte el juego, y en realidad no has llegado ni al 50%.<br/>
            Otra de las razones por las que la historia destaca tanto es por su mensaje. En un época donde las historias de ciencias ficción niponas están en su apogeo, <em>utilizando el progreso humano</em> para <dfn title=\"En Evangelion, Mazinger Z, Mobile Suit Gundam y Power Ranger, por ejemplo, usaban robots para combatir a los enemigos\">combatir problemas</dfn>
                  fue su mensaje anarco-primitivista. Dice que deberíamos dejar la tecnología y las empresas, las responsables del gran daño que ha recibido la madre gaia, y volver a nuestras raíces como seres nómadas.</p>
          </div>

          <h3>Plataformas</h3>
          <div id=\"informacionAdicional\">
            <p>Aunque el juego es muy antiguo, se puede jugar en muchas plataformas. Aquí se proporciona una lista de esas plataformas:</p>
            <ul>
              <li>Steam(Ordenador)</li>
              <li>PlayStation1(y la 2)</li>
              <li>Xbox One</li>
              <li>Android</li>
              <li>PlayStation Portable</li>
              <li>iOs</li>
              <li>Nintendo Switch<br/>En esta última plataforma es más difícil jugar al juego.Hay que:<ol>
                <li>Comprar o tener una Nintendo Switch</li>
                <li>Registrarse en Nintendo y vincular la cuenta con la consola</li>
                <li>Ya sea vinculando una tarjeta de crédito o registrando un código especial, hay que ingresar dinero en la cuenta.</li>
                <li>(Acceso a internet necesario) Usar el programa \"Nintendo Eshop\" y buscar Final Fantasy VII</li>
                <li>Seleccionar el juego deseado, comprarlo y descargarlo</li>
                <li>Volver al menú Home y jugar al juego</li>
              </ol></li>
            </ul>
          </div>
        </div>
";
    }

    // line 81
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 82
        echo "    <p>Fuentes: <a hreflang=\"es\" href=\"https://www.hobbyconsolas.com/noticias/final-fantasy-vii-lleva-vendidas-123-millones-copias-lanzamiento-521885\">Hobbyconsolas</a></p>
";
    }

    public function getTemplateName()
    {
        return "general/generalInfo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 82,  177 => 81,  139 => 46,  134 => 44,  129 => 42,  124 => 40,  119 => 38,  114 => 36,  109 => 34,  104 => 32,  99 => 30,  81 => 14,  77 => 13,  71 => 9,  68 => 8,  64 => 7,  57 => 5,  50 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "general/generalInfo.html.twig", "/home/alumno/Escritorio/ProyectoFinal/AlejMiraFFVII/aleMirFFVII/templates/general/generalInfo.html.twig");
    }
}
