<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* general/index.html.twig */
class __TwigTemplate_bd43f3736c34bdcc36302ced8e36ecd0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'keywords' => [$this, 'block_keywords'],
            'description' => [$this, 'block_description'],
            'javascripts' => [$this, 'block_javascripts'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "general/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Home";
    }

    // line 5
    public function block_keywords($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"wiki, FFVII, final fantasy, final fantasy 7, final fantasy VII, informacion\"";
    }

    // line 8
    public function block_description($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"Wiki que reune todos los datos del juego FFVII y toda información relacionada a este.\" ";
    }

    // line 11
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "      <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/SendForm.js"), "html", null, true);
        echo "\" ></script>
";
    }

    // line 16
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 17
        echo "            <h2>Home</h2>
            <br>
            <p>Final Fantasy VII es uno de los juegos más vendidos de la historia, y uno de los más influyentes en el mercado de los jrpg. El próposito de esta página es proporcionar información del juego.<br>
                Para ello he dividido la página en varias secciones distintas. En:</p>
            <ul>
            <li><a href=\"";
        // line 22
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_generalInfo");
        echo "\" hreflang=\"es\" type=\"text/html\"><img src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/FinalFantasyLogo.jpeg"), "html", null, true);
        echo "\" alt=\"Final Fantasy VII\" width=\"500\"/><br>Final Fantasy </a><br><br><br></li>
            <li><a hreflang=\"es\" type=\"text/html\" href=\"";
        // line 23
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters");
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/MonstruosImage.png"), "html", null, true);
        echo "\" height=\"300\" alt=\"Monstruos,imagen\"/><br>Monstruos</a></li>
            </ul>
            <br><br>
            <p>Si tiene alguna duda del juego que la página no haya podido responder, puede enviarnos la pregunta en el siguiente formulario. </p>
            <form action=\"Almacenamientos_de_preguntas\" method=\"post\" id=\"feedbackForm\" >
            <p>
            <label>
\t\t    Escriba su pregunta:
\t\t    <input type=\"text\" name=\"Pregunta\" value=\"\" id=\"feedback\" >
\t\t    <br>
\t    </label>
            <input type=\"submit\" value=\"Enviar\" >
            <input type=\"reset\" name=\"limpiar\" value=\"Borrar datos del formulario\" id=\"resetForm\" >
            </p>
            </form>
            <br><br>
";
    }

    // line 42
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "    
    <p><a href=\"https://commons.wikimedia.org/wiki/File:Cactuar.png\">Licencia de la imagen del cactilio. </a> Se ha modificado dicha imagen para que hubiesen 3 cactilios, en vez de uno.</p>
";
    }

    public function getTemplateName()
    {
        return "general/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 42,  100 => 23,  94 => 22,  87 => 17,  83 => 16,  76 => 12,  72 => 11,  65 => 8,  58 => 5,  51 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "general/index.html.twig", "/home/alumno/Escritorio/ProyectoFinal/AlejMiraFFVII/aleMirFFVII/templates/general/index.html.twig");
    }
}
