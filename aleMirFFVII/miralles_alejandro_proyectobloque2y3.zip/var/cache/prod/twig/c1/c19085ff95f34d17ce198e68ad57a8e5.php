<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* monsters/joker.html.twig */
class __TwigTemplate_aa349dbb04ea1d1814ee4762237bc466 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'keywords' => [$this, 'block_keywords'],
            'description' => [$this, 'block_description'],
            'javascripts' => [$this, 'block_javascripts'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "monsters/joker.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Joker";
    }

    // line 5
    public function block_keywords($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"wiki, FFVII, final fantasy, final fantasy 7, final fantasy VII, informacion, enemigo, monstruo, joker, desierto\"";
    }

    // line 7
    public function block_description($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"Pagina que reune toda la informacion del monstruo de FFVII Joker.\"";
    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/ExpandImg.js"), "html", null, true);
        echo "\"></script> ";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "                <h2><a id=\"home2\" hreflang=\"es\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_index");
        echo "\">Home</a>-<a hreflang=\"es\" type=\"text/html\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters");
        echo "\">Monstruos</a>-Joker</h2>
                <br><h1>Joker</h1><br/>
                
                
                <img class=\"adjunto img-responsive\" alt=\"Imagen del joker\" src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/Joker.png"), "html", null, true);
        echo "\">
                <!--HTML para crear una nueva imagen. Es la misma de arriba pero más grande-->
                <div id=\"myModal\" class=\"modal\">
                    <span class=\"close\">&times;</span>
                    <img class=\"modal-content img-responsive\" id=\"img01\">
                    <div id=\"caption\"></div>
                </div>


                <p>El joker es un monstruo sin debilidades. Suelen aparecer en los alrededores del desierto. Aunque sea un monstruo, tiene una figura humanoide y viste ropas humanas, que recuerdan a las de un bufón.</p>
                <p>Se les suele ver flotando sobre unas cartas, afirmando así su semblanza con los jokers de las cartas de poker.</p>

                <table>
                    <caption>Tabla entre nivel hp magia y movimientos</caption>
                    <thead>
                        <tr>
                            <th scope=\"row\">Nivel</th>
                            <th></th>
                            <th scope=\"col\">15</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope=\"row\">Experiencia</th>
                            <th></th>
                            <td>150</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Vida</th>
                            <th></th>
                            <td>700</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Magia</th>
                            <th></th>
                            <td>200</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Movimientos</th>
                            <th></th>
                            <td>Cartas*</td>
                        </tr>
                        <tr>
                            <th scope=\"row\">Objetos</th>
                            <th></th>
                            <td>Dados</td>
                        </tr>
                    </tbody>   
                </table>

                <br>
                <p>Curiosamente, este monstruo es una gran amenaza para los speedrunners por su capacidad de provocar muertes instantaneas. Por ello se suele huir de los jokers nada más verlos.<p>
            </content>
        </div>
";
    }

    // line 74
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 75
        echo "    <p><strong>Cartas*=</strong>Magia única del joker. Consiste en tirar una carta que puede usar alguna magia de daño, curar o incluso causar una muerte instantanea. El efecto se decide aleatoriamente.</p>
";
    }

    public function getTemplateName()
    {
        return "monsters/joker.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 75,  155 => 74,  95 => 16,  85 => 12,  81 => 11,  72 => 9,  65 => 7,  58 => 5,  51 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "monsters/joker.html.twig", "/home/alumno/Escritorio/ProyectoFinal/AlejMiraFFVII/aleMirFFVII/templates/monsters/joker.html.twig");
    }
}
