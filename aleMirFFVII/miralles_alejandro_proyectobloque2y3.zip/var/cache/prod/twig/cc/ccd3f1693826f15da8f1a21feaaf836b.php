<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* monsters/index.html.twig */
class __TwigTemplate_0d0643b5dccdf7151bdcd026f81e8244 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'keywords' => [$this, 'block_keywords'],
            'description' => [$this, 'block_description'],
            'javascripts' => [$this, 'block_javascripts'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "monsters/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Monstruos";
    }

    // line 5
    public function block_keywords($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"wiki, FFVII, final fantasy, final fantasy 7, final fantasy VII, informacion, monstruo, monstruos, puertos, enlaces\"";
    }

    // line 7
    public function block_description($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "\"Pagina puerto que sirve como puerto para todas las paginas de monstruos\" ";
    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/ShowMonsterCategory.js"), "html", null, true);
        echo "\" ></script>  ";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "                <div id= \"Lista_de_Monstruos\">
                    <h2><a id=\"home2\" hreflang=\"es\" href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_index");
        echo "\">Home</a>-Monstruos</h2>
                    <br/>
                    <ul id=\"categorias\">
                        <li><input type=\"button\" class=\"all\" value=\"Todos\" > </li>
                        <li><input type=\"button\" class=\"humanoid\" value=\"Humanoide\" > </li>
                        <li><input type=\"button\" class=\"dessert\" value=\"Desierto\" > </li>
                        <li><input type=\"button\" class=\"boss\" value=\"Jefe\" > </li>
                    </ul>
                    <ul id=\"monstruosIndexados\" >
                        <li class=\"humanoid\" ><a hreflang=\"es\" type=\"text/html\" href=\"";
        // line 22
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters_soldadoRaso");
        echo "\"><img alt=\"Imagen soldado\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/SoldadoRaso.png"), "html", null, true);
        echo "\" height=\"300\"><br/>Soldado Raso</a></li>
                        <li class=\"dessert\" ><a hreflang=\"es\" type=\"text/html\" href=\"";
        // line 23
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters_joker");
        echo "\"><img alt=\"Imagen Joker\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/Joker.png"), "html", null, true);
        echo "\" height=\"300\"><br>Joker</a></li>
                        <li class=\"humanoid\" ><a hreflang=\"es\" type=\"text/html\" href=\"";
        // line 24
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters_ladron");
        echo "\"><img  alt=\"Imagen Ladron\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/Ladron.png"), "html", null, true);
        echo "\" height=\"300\"><br>Ladrón</a></li>
                        <li class=\"boss, dessert\" ><a hreflang=\"es\" type=\"text/html\" href=\"";
        // line 25
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_monsters_serpienteKalm");
        echo "\"><img  alt=\"Imagen Serpiente\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/Serpiente.png"), "html", null, true);
        echo "\" height=\"300\"><br>Serpiente Kalm</a></li>
                    </ul>
                </div>
";
    }

    // line 31
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "monsters/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 31,  118 => 25,  112 => 24,  106 => 23,  100 => 22,  88 => 13,  85 => 12,  81 => 11,  72 => 9,  65 => 7,  58 => 5,  51 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "monsters/index.html.twig", "/home/alumno/Escritorio/ProyectoFinal/AlejMiraFFVII/aleMirFFVII/templates/monsters/index.html.twig");
    }
}
